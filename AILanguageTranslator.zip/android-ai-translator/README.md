# AI Language Translator — Android App

A modern Android application for AI-powered language translation built with **Kotlin**, **MVVM architecture**, **Retrofit**, **Room**, and **Material Design 3**.

---

## Features

| Feature | Details |
|---|---|
| **Translation** | LibreTranslate REST API (free, open-source) |
| **8 Languages** | English, Urdu, Hindi, Arabic, French, Spanish, Chinese, German |
| **Swap Languages** | One-tap swap with animated swap button |
| **Translation History** | Room database, RecyclerView with DiffUtil |
| **Text-to-Speech** | Android TTS engine for any translated text |
| **Copy to Clipboard** | One-tap copy of translated text |
| **Dark Mode** | Full Material 3 dark/light theme toggle |
| **Character Counter** | Live count as you type |
| **Input Validation** | Empty text, same language, no network |
| **Loading Indicator** | Linear progress indicator during API call |
| **Error Handling** | Rate limits, bad keys, network failures |

---

## Project Structure

```
AILanguageTranslator/
├── app/
│   ├── build.gradle                    # App dependencies & buildConfig fields
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/aitranslator/
│       │   ├── data/
│       │   │   ├── local/
│       │   │   │   ├── HistoryDao.kt           # Room DAO
│       │   │   │   └── TranslationDatabase.kt  # Room database singleton
│       │   │   ├── model/
│       │   │   │   ├── HistoryItem.kt          # Room entity + Parcelable
│       │   │   │   ├── Language.kt             # Language data class + supported list
│       │   │   │   ├── TranslationRequest.kt   # API request body
│       │   │   │   └── TranslationResponse.kt  # API response body
│       │   │   └── repository/
│       │   │       └── TranslationRepository.kt # Bridges ViewModel ↔ API + DB
│       │   ├── network/
│       │   │   ├── RetrofitClient.kt           # OkHttp + Retrofit singleton
│       │   │   └── TranslationApiService.kt    # Retrofit interface
│       │   ├── ui/
│       │   │   ├── history/
│       │   │   │   ├── HistoryActivity.kt      # History screen
│       │   │   │   └── HistoryAdapter.kt       # RecyclerView adapter (ListAdapter)
│       │   │   └── main/
│       │   │       └── MainActivity.kt         # Main translation screen
│       │   ├── utils/
│       │   │   ├── Extensions.kt               # Kotlin extension functions
│       │   │   ├── NetworkUtils.kt             # Internet connectivity check
│       │   │   └── TextToSpeechManager.kt      # Android TTS wrapper
│       │   └── viewmodel/
│       │       ├── HistoryViewModel.kt         # ViewModel for history screen
│       │       └── MainViewModel.kt            # ViewModel for main screen
│       └── res/
│           ├── anim/                           # fade_in_slide_up, rotate_swap
│           ├── drawable/                       # Vector icons + spinner background
│           ├── layout/                         # activity_main, activity_history, item_history
│           ├── menu/                           # menu_main, menu_history
│           ├── values/                         # strings, colors, themes (light)
│           ├── values-night/                   # themes (dark)
│           └── xml/                            # network_security_config
├── build.gradle                                # Root project build file
├── settings.gradle
└── gradle.properties
```

---

## Setup Instructions

### Prerequisites

- **Android Studio Hedgehog** (2023.1.1) or newer
- **JDK 17** (bundled with Android Studio)
- **Android SDK** — API 24+ (minSdk) / API 34 (compileSdk)
- Active internet connection for the translation API

---

### Step 1 — Open the Project

1. Launch **Android Studio**.
2. Choose **File → Open** and select the `AILanguageTranslator/` root folder.
3. Let Gradle sync finish (first sync downloads ~300 MB of dependencies).

---

### Step 2 — Configure the Translation API

The app uses **LibreTranslate** — a free, open-source translation API.

#### Option A — Use the public endpoint (quickest start)

1. Open `app/build.gradle`.
2. The base URL is already set:
   ```groovy
   buildConfigField "String", "LIBRE_TRANSLATE_BASE_URL", "\"https://libretranslate.com/\""
   ```
3. Get a **free API key** at https://libretranslate.com/ (click "Get API Key").
4. Paste your key:
   ```groovy
   buildConfigField "String", "LIBRE_TRANSLATE_API_KEY", "\"paste-your-key-here\""
   ```

#### Option B — Self-host LibreTranslate (no rate limits)

1. Run LibreTranslate locally with Docker:
   ```bash
   docker run -ti --rm -p 5000:5000 libretranslate/libretranslate
   ```
2. Update the base URL in `app/build.gradle`:
   ```groovy
   buildConfigField "String", "LIBRE_TRANSLATE_BASE_URL", "\"http://10.0.2.2:5000/\""
   ```
   > `10.0.2.2` is how the Android emulator reaches `localhost` on your host machine.
3. Leave the API key as an empty string — self-hosted instances don't require one by default.

#### Option C — Google Cloud Translation API

If you prefer Google Translate:

1. Enable the **Cloud Translation API** in [Google Cloud Console](https://console.cloud.google.com/).
2. Create an API key and add it to `build.gradle`.
3. In `TranslationApiService.kt`, change the endpoint to:
   ```
   https://translation.googleapis.com/language/translate/v2
   ```
4. Update `TranslationRequest` and `TranslationResponse` to match Google's JSON schema:
   - Request: `{ "q": "...", "source": "en", "target": "fr", "key": "YOUR_KEY" }`
   - Response: `{ "data": { "translations": [{ "translatedText": "..." }] } }`

---

### Step 3 — Add a Launcher Icon

The project references `@mipmap/ic_launcher`. Add your icon:

1. Right-click `res/` → **New → Image Asset**.
2. Choose **Launcher Icons (Adaptive and Legacy)**.
3. Set your source image and click **Finish**.

---

### Step 4 — Run the App

1. Start an **Android emulator** (API 24+) or connect a physical device with USB debugging on.
2. Click the green **Run ▶** button in Android Studio.
3. The app will build, install, and launch on your device.

---

## Architecture (MVVM)

```
View (Activity/Adapter)
    │  observes LiveData
    ▼
ViewModel  ─────────────────────────────────────────
    │  calls suspend funs on IO dispatcher           │
    ▼                                                ▼
Repository                                    Room Database
    │                                         (HistoryDao)
    ▼
Retrofit / OkHttp
    │
    ▼
LibreTranslate REST API
```

- **View** — `MainActivity`, `HistoryActivity`, `HistoryAdapter` — only observe and dispatch events.
- **ViewModel** — `MainViewModel`, `HistoryViewModel` — hold `LiveData`, validate input, call the repository.
- **Repository** — `TranslationRepository` — single source of truth; abstracts API and DB from ViewModels.
- **Model** — data classes in `data/model/`; Room entities; Retrofit request/response bodies.

---

## Dependencies

| Library | Version | Purpose |
|---|---|---|
| Kotlin | 1.9.22 | Language |
| AndroidX Core KTX | 1.12.0 | Kotlin extensions |
| Material 3 | 1.11.0 | UI components + theming |
| Lifecycle (ViewModel/LiveData) | 2.7.0 | MVVM state management |
| Retrofit 2 | 2.9.0 | HTTP client for translation API |
| OkHttp | 4.12.0 | HTTP networking + logging |
| Gson | 2.10.1 | JSON serialization |
| Room | 2.6.1 | Local SQLite database |
| Coroutines | 1.7.3 | Async/background operations |
| KSP | 1.9.22-1.0.17 | Room annotation processing |

---

## Permissions

| Permission | Reason |
|---|---|
| `INTERNET` | Required to call the translation API |
| `ACCESS_NETWORK_STATE` | Check connectivity before making requests |

---

## Expected User Flow

```
App opens
  └─▶ MainActivity
        ├─ Enter text in multi-line input
        ├─ Select source language (spinner)
        ├─ Select target language (spinner)
        ├─ [Optional] Tap ⇄ to swap languages
        ├─ Tap "Translate"
        │     ├─ Loading indicator appears
        │     ├─ API call sent via Retrofit
        │     └─ Result displayed in output card
        │           ├─ Tap "Copy" → clipboard
        │           └─ Tap "Listen" → TTS speaks translation
        └─ Tap history icon → HistoryActivity
              ├─ RecyclerView lists all past translations
              ├─ Tap "Copy" on any item → clipboard
              ├─ Tap "Delete" on any item → removes it
              └─ Menu → "Clear All" → wipes entire history
```

---

## Common Issues

| Problem | Fix |
|---|---|
| `403 Forbidden` from API | Your API key is missing or invalid. Check `build.gradle`. |
| `429 Too Many Requests` | You've hit the rate limit. Wait or self-host LibreTranslate. |
| TTS not working | Some emulators lack a TTS engine. Test on a physical device. |
| Emulator can't reach self-hosted API | Use `10.0.2.2` instead of `localhost` as the base URL. |
| Gradle sync fails | Make sure JDK 17 is selected: **File → Project Structure → SDK Location**. |

---

## License

MIT — free to use, modify, and distribute.
