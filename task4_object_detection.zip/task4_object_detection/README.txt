TASK 4: Object Detection and Tracking
======================================
Real-time object detection and tracking using YOLOv8 + OpenCV.

REQUIREMENTS
------------
Python 3.8 or newer must be installed on your computer.

Install the two required libraries:
    pip install ultralytics opencv-python

The YOLOv8 model weights (~6 MB) are downloaded automatically on first run.

FILES
-----
  object_detection_tracking.py   — main script (all-in-one)

USAGE
-----

1. Run with webcam (default):
       python object_detection_tracking.py

2. Run with a specific webcam index:
       python object_detection_tracking.py --source 1

3. Run with a video file:
       python object_detection_tracking.py --source path/to/video.mp4

4. Save annotated output to a video file:
       python object_detection_tracking.py --save
       python object_detection_tracking.py --save --output my_output.mp4

5. Log every detection to a CSV file:
       python object_detection_tracking.py --log
       python object_detection_tracking.py --log --log-file detections.csv

6. Save video AND log CSV at the same time:
       python object_detection_tracking.py --save --log

7. Headless mode (no window, process a file, save both outputs):
       python object_detection_tracking.py --source input.mp4 --save --log --no-display

8. Use a larger, more accurate model:
       python object_detection_tracking.py --model yolov8m.pt

9. Switch tracker algorithm:
       python object_detection_tracking.py --tracker botsort.yaml

10. Adjust confidence threshold:
        python object_detection_tracking.py --conf 0.5

Press 'q' in the live window to quit at any time.

ALL FLAGS
---------
  --source FILE_OR_INT   Video source: webcam index (0,1,...) or video file path
  --model  FILE          YOLOv8 weights: yolov8n.pt / yolov8s.pt / yolov8m.pt /
                         yolov8l.pt / yolov8x.pt  (nano is default, fastest)
  --tracker YAML         bytetrack.yaml (default) or botsort.yaml
  --conf   FLOAT         Detection confidence threshold, 0.0-1.0 (default 0.3)
  --save                 Record annotated video to file
  --output FILE          Custom video output filename (used with --save)
  --log                  Write per-detection CSV log to file
  --log-file FILE        Custom CSV filename (used with --log)
  --no-display           Disable live window (headless); requires --save or --log

CSV LOG COLUMNS
---------------
  timestamp_ms   Wall-clock time in milliseconds when the frame was processed
  frame_index    Sequential frame number (1-based)
  track_id       Unique tracking ID (empty if unavailable)
  class_id       YOLO integer class index
  class_name     Human-readable label (e.g. "person", "car")
  confidence     Detection confidence score (0.0 – 1.0)
  x1, y1         Top-left corner of bounding box (pixels)
  x2, y2         Bottom-right corner of bounding box (pixels)

FEATURES
--------
  - Real-time video input (webcam or video file) via OpenCV
  - YOLOv8 object detection (80 COCO classes out of the box)
  - ByteTrack / BoT-SORT tracking with persistent IDs across frames
  - Colour-coded bounding boxes (one colour per object class)
  - Live FPS counter with REC badge when recording
  - Optional video recording (annotated output identical to live view)
  - Optional CSV detection log for offline analysis
  - Headless / server mode (--no-display)
